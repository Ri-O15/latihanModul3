import React from "react";
import{Navbar} from "../components/Navbar";

const Contact = () => {
    return(
        <div>
            <Navbar />
            <div>   INI HALAMAN Contact</div>
        </div>
    );
};

export default Contact;
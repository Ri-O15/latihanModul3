import React from "react";
import{Navbar} from "../components/Navbar";

const About = () => {
    return(
        <div>
            <Navbar />
            <div>   INI HALAMAN ABOUT</div>
        </div>
    );
};

export default About;
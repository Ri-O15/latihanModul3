import React from 'react';
import "./App.css";
import { Navbar } from "./components/Navbar";

function App(){
    return(
        <div>
            <div> <h2>Navbar</h2></div>
            <Navbar />
            <div> INI HALAMAN HOME  </div>
        </div>
    );
}

export default App;